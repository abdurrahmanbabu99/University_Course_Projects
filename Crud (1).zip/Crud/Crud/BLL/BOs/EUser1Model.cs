﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.BOs
{
    public class EUser1Model
    {
        public int uId { get; set; }
        public string uName { get; set; }
        public string uUserName { get; set; }
        public string uEmail { get; set; }
        public string uGender { get; set; }
        public string uPassword { get; set; }

    }
}
