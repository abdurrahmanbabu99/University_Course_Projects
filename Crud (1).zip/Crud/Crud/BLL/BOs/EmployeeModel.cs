﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.BOs
{
    public class EmployeeModel
    {
        

        public int eId { get; set; }
        public string eName { get; set; }
        public string eUserName { get; set; }
        public string eEmail { get; set; }
        public string eGender { get; set; }
        public string ePassword { get; set; }
    }
}
