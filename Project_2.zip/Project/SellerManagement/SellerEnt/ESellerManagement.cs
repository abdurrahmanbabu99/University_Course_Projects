﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SellerManagement.Ent
{
    public class ESellerManagement
    {
        public int Id
        {
            set;
            get;
        }
        public string Name
        {
            set;
            get;
        }
        public int Age
        {
            set;
            get;
        }
        public string Phone
        {
            set;
            get;
        }
        public string Password
        {
            set;
            get;
        }
    }
}
