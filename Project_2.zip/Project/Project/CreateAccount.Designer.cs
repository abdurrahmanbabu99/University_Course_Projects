﻿
namespace Project
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SPass = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.SPhone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.SAge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            this.SName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.Sid = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(541, 400);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 56);
            this.button4.TabIndex = 16;
            this.button4.Text = "ADD";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(401, 318);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 29);
            this.label6.TabIndex = 15;
            this.label6.Text = "PASSWORD";
            // 
            // SPass
            // 
            this.SPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SPass.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SPass.HintForeColor = System.Drawing.Color.Empty;
            this.SPass.HintText = "";
            this.SPass.isPassword = false;
            this.SPass.LineFocusedColor = System.Drawing.Color.Black;
            this.SPass.LineIdleColor = System.Drawing.Color.Red;
            this.SPass.LineMouseHoverColor = System.Drawing.Color.Black;
            this.SPass.LineThickness = 3;
            this.SPass.Location = new System.Drawing.Point(555, 311);
            this.SPass.Margin = new System.Windows.Forms.Padding(4);
            this.SPass.Name = "SPass";
            this.SPass.Size = new System.Drawing.Size(255, 36);
            this.SPass.TabIndex = 10;
            this.SPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // SPhone
            // 
            this.SPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SPhone.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SPhone.HintForeColor = System.Drawing.Color.Empty;
            this.SPhone.HintText = "";
            this.SPhone.isPassword = false;
            this.SPhone.LineFocusedColor = System.Drawing.Color.Black;
            this.SPhone.LineIdleColor = System.Drawing.Color.Red;
            this.SPhone.LineMouseHoverColor = System.Drawing.Color.Black;
            this.SPhone.LineThickness = 3;
            this.SPhone.Location = new System.Drawing.Point(555, 267);
            this.SPhone.Margin = new System.Windows.Forms.Padding(4);
            this.SPhone.Name = "SPhone";
            this.SPhone.Size = new System.Drawing.Size(255, 36);
            this.SPhone.TabIndex = 11;
            this.SPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(401, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 29);
            this.label5.TabIndex = 6;
            this.label5.Text = "PHONE";
            // 
            // SAge
            // 
            this.SAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SAge.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SAge.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SAge.HintForeColor = System.Drawing.Color.Empty;
            this.SAge.HintText = "";
            this.SAge.isPassword = false;
            this.SAge.LineFocusedColor = System.Drawing.Color.Black;
            this.SAge.LineIdleColor = System.Drawing.Color.Red;
            this.SAge.LineMouseHoverColor = System.Drawing.Color.Black;
            this.SAge.LineThickness = 3;
            this.SAge.Location = new System.Drawing.Point(555, 223);
            this.SAge.Margin = new System.Windows.Forms.Padding(4);
            this.SAge.Name = "SAge";
            this.SAge.Size = new System.Drawing.Size(255, 36);
            this.SAge.TabIndex = 12;
            this.SAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(401, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 29);
            this.label4.TabIndex = 7;
            this.label4.Text = "AGE";
            // 
            // SName
            // 
            this.SName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SName.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SName.HintForeColor = System.Drawing.Color.Empty;
            this.SName.HintText = "";
            this.SName.isPassword = false;
            this.SName.LineFocusedColor = System.Drawing.Color.Black;
            this.SName.LineIdleColor = System.Drawing.Color.Red;
            this.SName.LineMouseHoverColor = System.Drawing.Color.Black;
            this.SName.LineThickness = 3;
            this.SName.Location = new System.Drawing.Point(555, 172);
            this.SName.Margin = new System.Windows.Forms.Padding(4);
            this.SName.Name = "SName";
            this.SName.Size = new System.Drawing.Size(255, 36);
            this.SName.TabIndex = 13;
            this.SName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(401, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 29);
            this.label3.TabIndex = 8;
            this.label3.Text = "NAME";
            // 
            // Sid
            // 
            this.Sid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Sid.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Sid.HintForeColor = System.Drawing.Color.Empty;
            this.Sid.HintText = "";
            this.Sid.isPassword = false;
            this.Sid.LineFocusedColor = System.Drawing.Color.Black;
            this.Sid.LineIdleColor = System.Drawing.Color.Red;
            this.Sid.LineMouseHoverColor = System.Drawing.Color.Black;
            this.Sid.LineThickness = 3;
            this.Sid.Location = new System.Drawing.Point(555, 128);
            this.Sid.Margin = new System.Windows.Forms.Padding(4);
            this.Sid.Name = "Sid";
            this.Sid.Size = new System.Drawing.Size(255, 36);
            this.Sid.TabIndex = 14;
            this.Sid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(401, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 29);
            this.label2.TabIndex = 9;
            this.label2.Text = "ID";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(853, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 32);
            this.button1.TabIndex = 17;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(514, 469);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 25);
            this.label1.TabIndex = 18;
            this.label1.Text = "Back to LOGIN";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // CreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(895, 565);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.SPass);
            this.Controls.Add(this.SPhone);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SAge);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Sid);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CreateAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateAccount";
            this.Load += new System.EventHandler(this.CreateAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SPass;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SPhone;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SAge;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SName;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Sid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}