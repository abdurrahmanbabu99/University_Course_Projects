﻿namespace Project
{
    internal class EBillManagement
    {
    }
}