﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.ProductEnt
{
    public class EProductManagement
    {
        public int Id
        {
            set;
            get;
        }
        public string Name
        {
            set;
            get;
        }
        public int Quantity
        {
            set;
            get;
        }
        public int Price
        {
            set;
            get;
        }
        public string Category
        {
            set;
            get;
        }

    }
}
